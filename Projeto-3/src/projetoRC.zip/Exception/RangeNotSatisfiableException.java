/**
 * 
 */
package Exception;

/** 
 * @author Rafael Gameiro nº50677
 * @author Rui Santos nº50833
 */
public class RangeNotSatisfiableException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * 
	 */
	public RangeNotSatisfiableException() {
		// TODO Auto-generated constructor stub
	}

}
